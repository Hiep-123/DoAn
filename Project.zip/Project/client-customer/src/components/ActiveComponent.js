import axios from 'axios';
import React, { Component } from 'react';
import { Navigate } from 'react-router-dom';

class Active extends Component {
    constructor(props) {
        super(props);
        this.state = {
            txtID: '',
            txtToken: '',
            redirectToLogin: false // Thêm trạng thái để điều hướng sang /login
        };
    }

    render() {
        if (this.state.redirectToLogin) {
            return <Navigate to="/login" />;
        }

        return (
            <div className="align-center">
                <h2 className="text-center">ACTIVE ACCOUNT</h2>
                <form>
                    <table className="align-center">
                        <tbody>
                            <tr>
                                <td>ID</td>
                                <td>
                                    <input 
                                        type="text" 
                                        value={this.state.txtID} 
                                        onChange={(e) => this.setState({ txtID: e.target.value })} 
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td>Token</td>
                                <td>
                                    <input 
                                        type="text" 
                                        value={this.state.txtToken} 
                                        onChange={(e) => this.setState({ txtToken: e.target.value })} 
                                    />
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                                    <input 
                                        type="submit" 
                                        value="ACTIVE" 
                                        onClick={(e) => this.btnActiveClick(e)} 
                                    />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
        );
    }

    // Event handler
    btnActiveClick(e) {
        e.preventDefault();
        const id = this.state.txtID;
        const token = this.state.txtToken;
        if (id && token) {
            this.apiActive(id, token);
        } else {
            alert('Please input ID and token');
        }
    }

    // API request
// API request
apiActive = (id, token) => {
    const body = { id, token };
    axios.post('/api/customer/active', body)
      .then((res) => {
        const result = res.data;
        if (result) {
          alert('OK BABY!');
          // Chờ 2 giây trước khi chuyển hướng
          setTimeout(() => {
            this.setState({ redirectToLogin: true });
          }, 2000); // 2000 milliseconds = 2 giây
        } else {
          alert('SORRY BABY!');
        }
      })
      .catch((error) => {
        console.error('API Error:', error);
        alert('Error occurred while trying to activate account.');
      });
}
}

export default Active;