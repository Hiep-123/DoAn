import React, { Component } from 'react';
class Home extends Component {
    render() {
        return (
            <div className="align-center">
                <h2 className="text-center">WELCOME TO OUR STORE</h2>
                <p className="text-center">Explore our wide range of products and find the best deals for you!</p>
            </div>
        );
    }
}

export default Home;
