const MyConstants = {
    DB_SERVER: 'clusternht.eit1sig.mongodb.net',
    DB_USER: 'gymptw1',
    DB_PASS: 'anhem123',
    DB_DATABASE: 'shoppingonline',
    JWT_SECRET: 'nguyenhuutruong',
    JWT_EXPIRES: '360000000', // in milliseconds
    EMAIL_USER: 'gymptw1@gmail.com', // gmail service
    EMAIL_PASS: 'ylgl cqxp drvp qarz'
  };
  module.exports = MyConstants;