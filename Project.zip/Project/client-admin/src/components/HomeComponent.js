import React, { Component } from 'react';

class Home extends Component {
    render() {
        return (
            <div className="align-center">
                <h2 className="text-center">ADMIN HOME</h2>
                <img src="https://cdn.pixabay.com/animation/2022/10/07/01/16/01-16-36-19_512.gif" type="image/webp" 
                     width="800px" height="600px" alt="" />
            </div>
        );
    }
}

export default Home;
