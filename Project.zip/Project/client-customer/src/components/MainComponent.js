import React, { useContext } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Menu from './MenuComponent';
import Inform from './InformComponent';
import Home from './HomeComponent';
import Signup from './SignupComponent';
import Login from './LoginComponent';
import Active from './ActiveComponent';
import Myprofile from './MyprofileComponent';
import MyContext from '../contexts/MyContext';
import TawkMessenger from './TawkMessengerComponent';

// Component bảo vệ route
const ProtectedRoute = ({ element }) => {
    const { token } = useContext(MyContext);
    return token ? element : <Navigate to="/login" replace />;
};

const Main = () => {
    const { token } = useContext(MyContext);
    const location = useLocation();
    const isLoginPage = location.pathname === "/login";

    return (
        <div className="body-customer">
            {!isLoginPage && token && <Menu />}
            {!isLoginPage && token && <Inform />}
            {token && <TawkMessenger />}
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/active" element={<Active />} />
                <Route path="/" element={<Navigate replace to={token ? "/home" : "/login"} />} />
                <Route path="/home" element={<ProtectedRoute element={<Home />} />} />
                <Route path="/myprofile" element={<ProtectedRoute element={<Myprofile />} />} />
            </Routes>
            
        </div>
    );
};

export default Main;
