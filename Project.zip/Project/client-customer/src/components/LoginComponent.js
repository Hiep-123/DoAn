import axios from 'axios';
import React, { Component } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { FaGoogle, FaFacebookF, FaGithub, FaLinkedinIn } from 'react-icons/fa';
import MyContext from '../contexts/MyContext';
import { motion } from 'framer-motion';
class Login extends Component {
  static contextType = MyContext;

  constructor(props) {
    super(props);
    this.state = {
      txtUsername: '',
      txtPassword: '',
      redirectToHome: false
    };
  }

  render() {
    if (this.state.redirectToHome) {
      return <Navigate to="/home" />;
    }

    return (
      <div className="login-container" style={styles.container}>
<div style={styles.card}>
  {/* Left Section with Framer Motion */}
  <motion.div 
    style={styles.leftSection} 
    initial="hidden" 
    animate="visible" 
    variants={leftSectionVariants}
  >
    <h2 style={styles.welcomeText}>Hello, Welcome!</h2>
    <p style={styles.subText}>Don't have an account?</p>
    <Link to="/signup">
      <button style={styles.registerButton}>Register</button>
    </Link>
  </motion.div>

          {/* Right Section */}
          <div style={styles.rightSection}>
            <h3 style={styles.title}>Login</h3>
            <form onSubmit={(e) => this.btnLoginClick(e)}>
              <table className="align-center" style={styles.table}>
                <tbody>
                  <tr>
                    <td style={styles.label}>Username</td>
                    <td>
                      <input
                        type="text"
                        value={this.state.txtUsername}
                        onChange={(e) => this.setState({ txtUsername: e.target.value })}
                        required
                        style={styles.input}
                      />
                    </td>
                  </tr>
                  <tr>
                    <td style={styles.label}>Password</td>
                    <td>
                      <input
                        type="password"
                        value={this.state.txtPassword}
                        onChange={(e) => this.setState({ txtPassword: e.target.value })}
                        required
                        style={styles.input}
                      />
                    </td>
                  </tr>
                  <tr>
                    <td></td>
                    <td>
                      <button type="submit" style={styles.loginButton}>LOGIN</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </form>

            {/* Social Login Section */}
            <div style={styles.socialLogin}>
              <p>or login with social platforms</p>
              <div style={styles.socialIcons}>
                <span style={styles.icon}><FaGoogle /></span>
                <span style={styles.icon}><FaFacebookF /></span>
                <span style={styles.icon}><FaGithub /></span>
                <span style={styles.icon}><FaLinkedinIn /></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  btnLoginClick(e) {
    e.preventDefault();
    const { txtUsername, txtPassword } = this.state;

    if (!txtUsername || !txtPassword) {
      alert('Please enter both username and password.');
      return;
    }

    const account = { username: txtUsername, password: txtPassword };
    this.apiLogin(account);
  }

  async apiLogin(account) {
    try {
      const res = await axios.post('/api/customer/login', account);
      const result = res.data;

      if (result.success) {
        this.context.setToken(result.token);
        this.context.setCustomer(result.customer);
        this.setState({ redirectToHome: true });
      } else {
        alert(result.message);
      }
    } catch (error) {
      alert('Login failed. Please check your network and try again.');
      console.error('Login error:', error);
    }
  }
}
const leftSectionVariants = {
  hidden: { x: -100, opacity: 0 },
  visible: { x: 0, opacity: 1, transition: { duration: 0.8, ease: "easeOut" } }
};
const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: '100vh',
    backgroundColor: '#e6f0fa',
  },
  card: {
    display: 'flex',
    width: '600px',
    height: '400px',
    backgroundColor: '#fff',
    borderRadius: '15px',
    overflow: 'hidden',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  },
  leftSection: {
    flex: 1,
    backgroundColor: '#4a90e2',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    color: '#fff',
    padding: '20px',
    borderTopRightRadius: '40%', 
    borderBottomRightRadius: '40%', 
  },
  rightSection: {
    flex: 1.5,
    padding: '40px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
  },
  welcomeText: {
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '10px',
  },
  subText: {
    fontSize: '14px',
    marginBottom: '20px',
  },
  registerButton: {
    padding: '10px 20px',
    backgroundColor: '#fff',
    color: '#4a90e2',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontWeight: 'bold',
  },
  title: {
    fontSize: '20px',
    marginBottom: '20px',
    textAlign: 'center',
  },
  table: {
    width: '100%',
  },
  label: {
    paddingRight: '10px',
    fontSize: '14px',
    textAlign: 'right',
  },
  input: {
    width: '100%',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    fontSize: '14px',
  },
  loginButton: {
    width: '100%',
    padding: '10px',
    backgroundColor: '#4a90e2',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '14px',
  },
  socialLogin: {
    textAlign: 'center',
    marginTop: '20px',
  },
  socialIcons: {
    display: 'flex',
    justifyContent: 'center',
    gap: '10px',
    marginTop: '10px',
  },
  icon: {
    width: '40px',
    height: '40px',
    backgroundColor: '#fff',
    borderRadius: '50%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    cursor: 'pointer',
    fontSize: '20px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
    transition: 'background-color 0.3s',
  },
};

export default Login;
