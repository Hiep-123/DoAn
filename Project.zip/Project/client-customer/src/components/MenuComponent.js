import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class Menu extends Component {
    render() {
        return (
            <div className="border-bottom">
                <div className="float-left">
                    <ul className="menu">
                        <li className="menu"><Link to='/'>Home</Link></li>
                    </ul>
                </div>
                <div className="float-right">
                    <form className="search">
                        <input type="search" placeholder="Enter keyword" className="keyword" />
                        <input type="submit" value="SEARCH" />
                    </form>
                </div>
                <div className="float-clear" />
            </div>
        );
    }
}

export default Menu;
