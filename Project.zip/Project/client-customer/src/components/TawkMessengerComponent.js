import React, { Component } from 'react';
import TawkMessengerReact from '@tawk.to/tawk-messenger-react';

class TawkMessenger extends Component {
  constructor(props) {
    super(props);
    this.tawkMessengerRef = React.createRef();
  }

  handleBeforeLoad = () => {
    console.log("TawkMessenger is loading...");
  };

  handleLoad = () => {
    console.log("TawkMessenger loaded successfully");
  };

  handleStatusChange = (status) => {
    console.log("Tawk status changed:", status);
  };

  render() {
    return (
      <TawkMessengerReact
        propertyId="667b9277eaf3bd8d4d146907"
        widgetId="1i19b8908"
        onBeforeLoad={this.handleBeforeLoad}
        onLoad={this.handleLoad}
        onStatusChange={this.handleStatusChange}
        ref={this.tawkMessengerRef}
      />
    );
  }
}

export default TawkMessenger;
