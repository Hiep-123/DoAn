import axios from 'axios';
import React, { Component } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { FaGoogle, FaFacebookF, FaGithub, FaLinkedinIn } from 'react-icons/fa';
import { motion } from 'framer-motion';

class Signup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      txtUsername: '',
      txtPassword: '',
      txtName: '',
      txtPhone: '',
      txtEmail: '',
      redirectToActive: false // Thêm trạng thái để điều hướng sang /active
    };
  }

  render() {
    if (this.state.redirectToActive) {
      return <Navigate to="/active" />;
    }

    return (
      <div className="signup-container" style={styles.container}>
        <div style={styles.card}>
          {/* Form đăng ký bên trái */}
          <div style={styles.leftSection}>
            <h3 style={styles.title}>Registration</h3>
            <form>
              <table className="align-center" style={styles.table}>
                <tbody>
                  <tr>
                    <td style={styles.label}>Username</td>
                    <td>
                      <input
                        type="text"
                        value={this.state.txtUsername}
                        onChange={(e) => this.setState({ txtUsername: e.target.value })}
                        style={styles.input}
                      />
                    </td>
                  </tr>
                  <tr>
                    <td style={styles.label}>Password</td>
                    <td>
                      <input
                        type="password"
                        value={this.state.txtPassword}
                        onChange={(e) => this.setState({ txtPassword: e.target.value })}
                        style={styles.input}
                      />
                    </td>
                  </tr>
                  <tr>
                    <td style={styles.label}>Name</td>
                    <td>
                      <input
                        type="text"
                        value={this.state.txtName}
                        onChange={(e) => this.setState({ txtName: e.target.value })}
                        style={styles.input}
                      />
                    </td>
                  </tr>
                  <tr>
                    <td style={styles.label}>Phone</td>
                    <td>
                      <input
                        type="tel"
                        value={this.state.txtPhone}
                        onChange={(e) => this.setState({ txtPhone: e.target.value })}
                        style={styles.input}
                      />
                    </td>
                  </tr>
                  <tr>
                    <td style={styles.label}>Email</td>
                    <td>
                      <input
                        type="email"
                        value={this.state.txtEmail}
                        onChange={(e) => this.setState({ txtEmail: e.target.value })}
                        style={styles.input}
                      />
                    </td>
                  </tr>
                  <tr>
                    <td></td>
                    <td>
                      <input
                        type="submit"
                        value="SIGN-UP"
                        onClick={(e) => this.btnSignupClick(e)}
                        style={styles.submitButton}
                      />
                    </td>
                  </tr>
                </tbody>
              </table>
            </form>

            {/* Social Login Section */}
            <div style={styles.socialLogin}>
              <p>or sign up with social platforms</p>
              <div style={styles.socialIcons}>
                <span style={styles.icon}><FaGoogle /></span>
                <span style={styles.icon}><FaFacebookF /></span>
                <span style={styles.icon}><FaGithub /></span>
                <span style={styles.icon}><FaLinkedinIn /></span>
              </div>
            </div>
          </div>
          
          {/* Phần "Welcome Back" bên phải */}
          <motion.div 
            style={styles.rightSection} 
            initial="hidden" 
            animate="visible" 
            variants={rightSectionVariants}
          >
            <h2 style={styles.welcomeText}>Welcome Back!</h2>
            <p style={styles.subText}>Already have an account?</p>
            <Link to="/login">
              <button style={styles.loginButton}>Login</button>
            </Link>
          </motion.div>
        </div>
      </div>
    );
  }

  // event-handlers
  btnSignupClick(e) {
    e.preventDefault();
    const username = this.state.txtUsername;
    const password = this.state.txtPassword;
    const name = this.state.txtName;
    const phone = this.state.txtPhone;
    const email = this.state.txtEmail;

    if (username && password && name && phone && email) {
      const account = { username, password, name, phone, email };
      this.apiSignup(account);
    } else {
      alert('Please input username and password and name and phone and email');
    }
  }

  // apis
// apis
apiSignup(account) {
  axios.post('/api/customer/signup', account).then((res) => {
    const result = res.data;
    if (result.success) { // Giả định API trả về { success: true, message: "..." }
      alert('Please check mail'); // Hiển thị thông báo
      // Chờ 2 giây trước khi chuyển hướng
      setTimeout(() => {
        this.setState({ redirectToActive: true });
      }, 2000); // 2000 milliseconds = 2 giây
    } else {
      alert(result.message);
    }
  }).catch((error) => {
    alert('An error occurred during signup. Please try again.');
    console.error('Signup error:', error);
  });
}
}

const rightSectionVariants = {
  hidden: { x: 100, opacity: 0 }, // Bắt đầu từ phải (100px)
  visible: { x: 0, opacity: 1, transition: { duration: 0.8, ease: "easeOut" } }
};

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    backgroundColor: '#e6f0fa',
  },
  card: {
    display: 'flex',
    width: '600px',
    height: '450px', 
    backgroundColor: '#fff',
    borderRadius: '15px',
    overflow: 'hidden',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  },
  leftSection: {
    flex: 1.5,
    padding: '40px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
  },
  rightSection: {
    flex: 1,
    backgroundColor: '#4a90e2',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    color: '#fff',
    padding: '20px',
    borderTopLeftRadius: '40%', 
    borderBottomLeftRadius: '40%', 
  },
  welcomeText: {
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '10px',
  },
  subText: {
    fontSize: '14px',
    marginBottom: '20px',
  },
  loginButton: {
    padding: '10px 20px',
    backgroundColor: '#fff',
    color: '#4a90e2',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontWeight: 'bold',
  },
  title: {
    fontSize: '20px',
    marginBottom: '20px',
    textAlign: 'center',
  },
  table: {
    width: '100%',
  },
  label: {
    paddingRight: '10px',
    fontSize: '14px',
    textAlign: 'right',
  },
  input: {
    width: '100%',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    fontSize: '14px',
  },
  submitButton: {
    padding: '10px',
    backgroundColor: '#4a90e2',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '14px',
    width: '100%',
  },
  socialLogin: {
    textAlign: 'center',
    marginTop: '20px',
  },
  socialIcons: {
    display: 'flex',
    justifyContent: 'center',
    gap: '10px',
    marginTop: '10px',
  },
  icon: {
    width: '40px',
    height: '40px',
    backgroundColor: '#fff',
    borderRadius: '50%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    cursor: 'pointer',
    fontSize: '20px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
    transition: 'background-color 0.3s',
  },
};

export default Signup;
