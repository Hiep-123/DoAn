const express = require('express');
const router = express.Router();

const CustomerDAO = require('../models/CustomerDAO');
const JwtUtil = require('../utils/JwtUtil');
const CryptoUtil = require('../utils/CryptoUtil');
const EmailUtil = require('../utils/EmailUtil');
// customer
router.post('/signup', async function (req, res) {
    const username = req.body.username;
    const password = req.body.password;
    const name = req.body.name;
    const phone = req.body.phone;
    const email = req.body.email;
    const dbCust = await CustomerDAO.selectByUsernameOrEmail(username, email);
    if (dbCust) {
      res.json({ success: false, message: 'Exists username or email' });
    } else {
      const now = new Date().getTime(); // milliseconds
      const token = CryptoUtil.md5(now.toString());
      const newCust = { username: username, password: password, name: name, phone: phone, email: email, active: 0, token: token };
      const result = await CustomerDAO.insert(newCust);
      if (result) {
        const send = await EmailUtil.send(email, result._id, token);
        if (send) {
          res.json({ success: true, message: 'Please check email' });
        } else {
          res.json({ success: false, message: 'Email failure' });
        }
      } else {
        res.json({ success: false, message: 'Insert failure' });
      }
    }
  });
  router.post('/active', async function (req, res) {
    const _id = req.body.id;
    const token = req.body.token;
    const result = await CustomerDAO.active(_id, token, 1);
    res.json(result);
  });
  router.post('/login', async function (req, res) {
    const username = req.body.username;
    const password = req.body.password;
    if (username && password) {
      const customer = await CustomerDAO.selectByUsernameAndPassword(username, password);
      if (customer) {
        if (customer.active === 1) {
          const token = JwtUtil.genToken(customer._id);
          res.json({ success: true, message: 'Authentication successful', token: token, customer: customer });
        } else {
          res.json({ success: false, message: 'Account is deactive' });
        }
      } else {
        res.json({ success: false, message: 'Incorrect username or password' });
      }
    } else {
      res.json({ success: false, message: 'Please input username and password' });
    }
  });
  router.get('/token', JwtUtil.checkToken, function (req, res) {
    const token = req.headers['x-access-token'] || req.headers['authorization'];
    const id = req.decoded.id;
    res.json({ success: true, message: 'Token is valid', token: token, id: id });
  });
  // myprofile
router.put('/customers/:id', JwtUtil.checkToken, async function (req, res) {
  const _id = req.params.id;
  const username = req.body.username;
  const password = req.body.password;
  const name = req.body.name;
  const phone = req.body.phone;
  const email = req.body.email;
  const customer = { _id: _id, username: username, password: password, name: name, phone: phone, email: email };
  const result = await CustomerDAO.update(customer);
  res.json(result);
});
module.exports = router;